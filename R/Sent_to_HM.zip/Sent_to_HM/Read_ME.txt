

#####################
#To Run the Code##
#####################

1. Open: "Wrapper_SVG_BENCHMARK"

2. Change directory at line: 42

3. Scenario and method inputs: 51-54